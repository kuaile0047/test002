package com.example.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.demo.po.User;

/**
 * Author: huangll
 * Written on 2018/10/25.
 */
public interface UserMapper extends BaseMapper<User>{
}
